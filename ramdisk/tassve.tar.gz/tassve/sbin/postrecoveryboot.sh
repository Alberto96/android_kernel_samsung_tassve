#!/sbin/sh

# allow device to settle to prevent format errors when doing rom manager rom updates
sleep 5

